#ifndef SQLITE_VEC_H
#define SQLITE_VEC_H

#include "sqlite3.h"

#define SQLITE_VEC_VERSION "v0.1.6"
#define SQLITE_VEC_VERSION_MAJOR 0
#define SQLITE_VEC_VERSION_MINOR 1
#define SQLITE_VEC_VERSION_PATCH 6

#ifndef SQLITE_VEC_DATE
#define SQLITE_VEC_DATE __DATE__
#endif

#ifndef SQLITE_VEC_SOURCE
#define SQLITE_VEC_SOURCE "unknown"
#endif

#ifndef SQLITE_VEC_DEBUG_BUILD
#define SQLITE_VEC_DEBUG_BUILD ""
#endif

#ifndef SQLITE_VEC_API
#define SQLITE_VEC_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

int sqlite3_vec_init(sqlite3 *db, char **pzErrMsg, const sqlite3_api_routines *pApi);

#ifdef __cplusplus
}
#endif

#endif /* SQLITE_VEC_H */
